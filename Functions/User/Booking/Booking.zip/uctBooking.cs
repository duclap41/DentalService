﻿using DentalService.Booking.Calender;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DentalService.Booking
{
    public partial class uctBooking : UserControl
    {
        Booking_Page1 page1;

        public uctBooking()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;

            page1 = new Booking_Page1();
            pnContainer.Controls.Add(page1);
        }
    }
}
