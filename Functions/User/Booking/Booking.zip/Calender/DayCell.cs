﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DentalService.Booking.Calender
{
    public partial class DayCell : UserControl
    {
        public DayCell()
        {
            InitializeComponent();
        }

        public void showDay(int numDay)
        {
            lbDay.Text = numDay.ToString();
        }

        private void lbDay_Click(object sender, EventArgs e)
        {
            preventManyPick();
            this.BackColor = Color.LightGray;

            Booking_Page1.choosedDay = Convert.ToInt32(lbDay.Text);
        }

        // Prevent can pick many day at once time
        private void preventManyPick()
        {
            foreach (Control cell in this.Parent.Controls)
            {
                if (cell.BackColor == Color.LightGray)
                {
                    cell.BackColor = Color.Transparent;
                    break;
                }
            }
        }
    }
}
