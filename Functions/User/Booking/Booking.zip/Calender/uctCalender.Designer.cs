﻿namespace DentalService.Booking.Calender
{
    partial class uctCalender
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uctCalender));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tblPnDay = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tblPnButton = new System.Windows.Forms.TableLayoutPanel();
            this.customPictureBox1 = new DentalService.CustomPictureBox();
            this.customPictureBox2 = new DentalService.CustomPictureBox();
            this.cFLPnDayContainer = new DentalService.CustomControls.CustomFlowLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.tblPnDay.SuspendLayout();
            this.tblPnButton.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customPictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Controls.Add(this.tblPnDay, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tblPnButton, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.cFLPnDayContainer, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(415, 350);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tblPnDay
            // 
            this.tblPnDay.ColumnCount = 7;
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPnDay.Controls.Add(this.label1, 0, 0);
            this.tblPnDay.Controls.Add(this.label2, 1, 0);
            this.tblPnDay.Controls.Add(this.label3, 2, 0);
            this.tblPnDay.Controls.Add(this.label4, 3, 0);
            this.tblPnDay.Controls.Add(this.label5, 4, 0);
            this.tblPnDay.Controls.Add(this.label6, 5, 0);
            this.tblPnDay.Controls.Add(this.label7, 6, 0);
            this.tblPnDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnDay.Location = new System.Drawing.Point(20, 0);
            this.tblPnDay.Margin = new System.Windows.Forms.Padding(0);
            this.tblPnDay.Name = "tblPnDay";
            this.tblPnDay.RowCount = 1;
            this.tblPnDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tblPnDay.Size = new System.Drawing.Size(373, 35);
            this.tblPnDay.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Chủ Nhật";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(56, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Thứ Hai";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(109, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 35);
            this.label3.TabIndex = 1;
            this.label3.Text = "Thứ Ba";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.Location = new System.Drawing.Point(162, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 35);
            this.label4.TabIndex = 1;
            this.label4.Text = "Thứ Tư";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(215, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 35);
            this.label5.TabIndex = 1;
            this.label5.Text = "Thứ Năm";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.Location = new System.Drawing.Point(268, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 35);
            this.label6.TabIndex = 1;
            this.label6.Text = "Thứ Sáu";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Roboto", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkBlue;
            this.label7.Location = new System.Drawing.Point(321, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 35);
            this.label7.TabIndex = 1;
            this.label7.Text = "Thứ Bảy";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tblPnButton
            // 
            this.tblPnButton.ColumnCount = 3;
            this.tblPnButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tblPnButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblPnButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblPnButton.Controls.Add(this.customPictureBox1, 1, 0);
            this.tblPnButton.Controls.Add(this.customPictureBox2, 2, 0);
            this.tblPnButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnButton.Location = new System.Drawing.Point(20, 280);
            this.tblPnButton.Margin = new System.Windows.Forms.Padding(0);
            this.tblPnButton.Name = "tblPnButton";
            this.tblPnButton.RowCount = 2;
            this.tblPnButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblPnButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblPnButton.Size = new System.Drawing.Size(373, 70);
            this.tblPnButton.TabIndex = 2;
            // 
            // customPictureBox1
            // 
            this.customPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.customPictureBox1.BackgroundColor = System.Drawing.Color.Transparent;
            this.customPictureBox1.BorderColor = System.Drawing.Color.DimGray;
            this.customPictureBox1.BorderRadius = 0;
            this.customPictureBox1.BorderSize = 0;
            this.customPictureBox1.ForeColor = System.Drawing.Color.Black;
            this.customPictureBox1.GradientBottomColor = System.Drawing.Color.CadetBlue;
            this.customPictureBox1.GradientTopColor = System.Drawing.Color.DodgerBlue;
            this.customPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("customPictureBox1.Image")));
            this.customPictureBox1.Location = new System.Drawing.Point(264, 3);
            this.customPictureBox1.Name = "customPictureBox1";
            this.customPictureBox1.Size = new System.Drawing.Size(49, 29);
            this.customPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customPictureBox1.TabIndex = 0;
            this.customPictureBox1.TabStop = false;
            this.customPictureBox1.UseGradient = false;
            // 
            // customPictureBox2
            // 
            this.customPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.customPictureBox2.BackgroundColor = System.Drawing.Color.Transparent;
            this.customPictureBox2.BorderColor = System.Drawing.Color.DimGray;
            this.customPictureBox2.BorderRadius = 0;
            this.customPictureBox2.BorderSize = 0;
            this.customPictureBox2.ForeColor = System.Drawing.Color.Black;
            this.customPictureBox2.GradientBottomColor = System.Drawing.Color.CadetBlue;
            this.customPictureBox2.GradientTopColor = System.Drawing.Color.DodgerBlue;
            this.customPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("customPictureBox2.Image")));
            this.customPictureBox2.Location = new System.Drawing.Point(319, 3);
            this.customPictureBox2.Name = "customPictureBox2";
            this.customPictureBox2.Size = new System.Drawing.Size(49, 29);
            this.customPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customPictureBox2.TabIndex = 0;
            this.customPictureBox2.TabStop = false;
            this.customPictureBox2.UseGradient = false;
            // 
            // cFLPnDayContainer
            // 
            this.cFLPnDayContainer.BackColor = System.Drawing.Color.AliceBlue;
            this.cFLPnDayContainer.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.cFLPnDayContainer.BorderColor = System.Drawing.Color.MediumBlue;
            this.cFLPnDayContainer.BorderRadius = 10;
            this.cFLPnDayContainer.BorderSize = 2;
            this.cFLPnDayContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cFLPnDayContainer.ForeColor = System.Drawing.Color.Black;
            this.cFLPnDayContainer.GradientBottomColor = System.Drawing.Color.CadetBlue;
            this.cFLPnDayContainer.GradientTopColor = System.Drawing.Color.DodgerBlue;
            this.cFLPnDayContainer.Location = new System.Drawing.Point(20, 35);
            this.cFLPnDayContainer.Margin = new System.Windows.Forms.Padding(0);
            this.cFLPnDayContainer.Name = "cFLPnDayContainer";
            this.cFLPnDayContainer.Size = new System.Drawing.Size(373, 245);
            this.cFLPnDayContainer.TabIndex = 3;
            this.cFLPnDayContainer.UseGradient = false;
            // 
            // uctCalender
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "uctCalender";
            this.Size = new System.Drawing.Size(415, 350);
            this.Load += new System.EventHandler(this.uctCalender_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tblPnDay.ResumeLayout(false);
            this.tblPnDay.PerformLayout();
            this.tblPnButton.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.customPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customPictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tblPnDay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tblPnButton;
        private CustomControls.CustomFlowLayoutPanel cFLPnDayContainer;
        private CustomPictureBox customPictureBox1;
        private CustomPictureBox customPictureBox2;
    }
}
