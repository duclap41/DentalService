﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DentalService.Booking.Calender
{
    public partial class uctCalender : UserControl
    {
        public uctCalender()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;              
        }

        private void uctCalender_Load(object sender, EventArgs e)
        {
            DisplayDays();
        }

        private void DisplayDays()
        {
            DateTime now = DateTime.Now;
            DateTime startOfMonth = new DateTime(now.Year, now.Month, 1); // get first day of month

            // Convert to interger
            int days = DateTime.DaysInMonth(now.Year, now.Month);
            int dayOfWeek = Convert.ToInt32(startOfMonth.DayOfWeek.ToString("d"));

            // Add day blank cell to ignore previous
            for (int i = 0; i < dayOfWeek; i++)
            {
                System.Windows.Forms.Label blankCell = new System.Windows.Forms.Label();
                blankCell.Size = new Size(47, 35);
                blankCell.BackColor = Color.Transparent;
                cFLPnDayContainer.Controls.Add(blankCell);
            }

            // add day number
            for (int i = 0; i < days; i++)
            {
                DayCell dayCell = new DayCell();
                dayCell.showDay(i);
                cFLPnDayContainer.Controls.Add(dayCell);

                if (now.Day == i)
                {
                    dayCell.BorderStyle = BorderStyle.FixedSingle;
                }
            }
        }
    }
}
