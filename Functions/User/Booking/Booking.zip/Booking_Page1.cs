﻿using DentalService.Booking.Calender;
using DentalService.CustomControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DentalService.Booking
{
    public partial class Booking_Page1 : UserControl
    {
        uctCalender uctCalender;

        public Booking_Page1()
        {
            InitializeComponent();

            uctCalender = new uctCalender();
            pnContainer.Controls.Add(uctCalender);
        }

        internal static int choosedDay = DateTime.Now.Day;
        private void Booking_Page1_Load(object sender, EventArgs e)
        {
            // Picking time in day
            lbTime1.Click += new EventHandler(chooseTime);
            lbTime2.Click += new EventHandler(chooseTime);
            lbTime3.Click += new EventHandler(chooseTime);
            lbTime4.Click += new EventHandler(chooseTime);
            lbTime5.Click += new EventHandler(chooseTime);
            lbTime6.Click += new EventHandler(chooseTime);
        }

        // Choose time in day
        private void chooseTime(object sender, EventArgs e)
        {
            preventManyPick();

            Label lbTime = (Label)sender;
            lbTime.Parent.BackColor = Color.LightGray;
        }

        // Preven choose many time at once
        private void preventManyPick()
        {
            foreach (Control cell in tblPnTime.Controls)
            {

                if (cell.BackColor == Color.LightGray)
                {
                    cell.BackColor = Color.AliceBlue;
                    break; // optimize
                }
            }
        }
    }
}
